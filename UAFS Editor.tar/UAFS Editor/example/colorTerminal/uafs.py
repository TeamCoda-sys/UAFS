import os #line:2
import zipfile #line:3
from zipfile import ZipFile #line:4
def UConsoleWrite (O000O0O00O000000O ):#line:6
    print (O000O0O00O000000O )#line:7
def UConsoleWriteColorBash (OO00O0O0OOOO0O0OO ,OO0O0OOO00OO00OO0 ):#line:9
    if OO00O0O0OOOO0O0OO =="red":#line:10
        os .system ("echo '\033[0;31m'"+OO0O0OOO00OO00OO0 )#line:11
    if OO00O0O0OOOO0O0OO =="green":#line:13
        os .system ("echo '\033[0;32m'"+OO0O0OOO00OO00OO0 )#line:14
    if OO00O0O0OOOO0O0OO =="orange":#line:16
        os .system ("echo '\033[0;33m'"+OO0O0OOO00OO00OO0 )#line:17
    if OO00O0O0OOOO0O0OO =="blue":#line:19
        os .system ("echo '\033[0;34m'"+OO0O0OOO00OO00OO0 )#line:20
    if OO00O0O0OOOO0O0OO =="purple":#line:22
        os .system ("echo '\033[0;35m'"+OO0O0OOO00OO00OO0 )#line:23
    if OO00O0O0OOOO0O0OO =="cyan":#line:25
        os .system ("echo '\033[0;36m'"+OO0O0OOO00OO00OO0 )#line:26
    if OO00O0O0OOOO0O0OO =="lightgray":#line:28
        os .system ("echo '\033[0;37m'"+OO0O0OOO00OO00OO0 )#line:29
    if OO00O0O0OOOO0O0OO =="darkgrey":#line:31
        os .system ("echo '\033[1;30m'"+OO0O0OOO00OO00OO0 )#line:32
    if OO00O0O0OOOO0O0OO =="yellow":#line:34
        os .system ("echo '\033[1;33m'"+OO0O0OOO00OO00OO0 )#line:35
def UConsoleInput (OO0OO00O00OO0OOOO ,OO0OOOOO000OO0O0O ):#line:37
    OO0OO00O00OO0OOOO =input (OO0OOOOO000OO0O0O )#line:38
def USystemShellCommand (OO0000000OOO0OOO0 ):#line:40
    os .system (OO0000000OOO0OOO0 )#line:41
def USystemListDirFile ():#line:43
    os .system ("ls")#line:44
def USystemMakeArchiveFile (OOO0O0O00OOOO0O0O ,O0OOOOOOOOO000000 ,OO000OO0OOOOO0O0O ):#line:46
    OOO0O0O00OOOO0O0O =ZipFile (O0OOOOOOOOO000000 +'.'+OO000OO0OOOOO0O0O ,'w')#line:47
    OOO0O0O00OOOO0O0O .close ()#line:48
def UConsoleSystemBashCreateFile (O0000OOOO0OOOOO00 ,O0O000O00O00OO000 ):#line:50
    os .system ("touch "+O0000OOOO0OOOOO00 +O0O000O00O00OO000 )#line:51
def UConsoleSystemBashWriteFile (O00000O00O0O00000 ,O00OOOO000OOO0O00 ):#line:53
    os .system ("echo "+O00OOOO000OOO0O00 +" >> "+O00000O00O0O00000 )#line:54
def UConsoleSystemBashCreateDirectory (O000OOO00OOOO0OO0 ):#line:56
    os .system ("mkdir "+O000OOO00OOOO0OO0 )#line:57
def UConsoleSystemBashDeleteDirectory (O0O0O0O00OO000OOO ):#line:59
    os .system ("rm -r "+O0O0O0O00OO000OOO )#line:60
def UConsoleSystemBashDeleteFile (O0O000OO0O000OO00 ):#line:62
    os .system ("rm "+O0O000OO0O000OO00 )#line:63
def USystemKernelHash (O0000O000O000O0OO ):#line:65
    os .system ("echo -n "+O0000O000O000O0OO +" | md5sum")#line:66
def USystemExecuteShellFile (OOOO0000OOOO0OOO0 ):#line:68
    os .system ("sh "+OOOO0000OOOO0OOO0 )#line:69
def USystemUNIXInfo ():#line:71
    os .system ("uname -a")#line:72
def USystemShellCurrentUser ():#line:74
    os .system ("whoami")#line:75
def USystemKernelSudo (OO0OOOOO000OO0OOO ):#line:77
    os .system ("sudo "+OO0OOOOO000OO0OOO )#line:78
def USystemKernelSudoApt (OO0OO0OO00O0OO000 ):#line:80
    os .system ("sudo apt "+OO0OO0OO00O0OO000 )#line:81
def USystemShellChmod (OOOOOOO0OO00O00O0 ,OO0OOOOO000O0OOO0 ):#line:83
    os .system ("chmod "+OOOOOOO0OO00O00O0 +OO0OOOOO000O0OOO0 )