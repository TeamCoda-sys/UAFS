echo Installing...
sudo apt install python3-tk
sudo apt install python3
echo You can now using Tkinter on Linux