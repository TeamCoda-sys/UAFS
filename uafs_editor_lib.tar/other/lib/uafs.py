# UASF KIT
import os
import zipfile
from zipfile import ZipFile

def UConsoleWrite(TextToWrite):
    print(TextToWrite)

def UConsoleWriteColorBash(nameOfColor, textOfColor):
    if nameOfColor == "red":
        os.system("echo '\033[0;31m'" + textOfColor)
    
    if nameOfColor == "green":
        os.system("echo '\033[0;32m'" + textOfColor)

    if nameOfColor == "orange":
        os.system("echo '\033[0;33m'" + textOfColor)

    if nameOfColor == "blue":
        os.system("echo '\033[0;34m'" + textOfColor)

    if nameOfColor == "purple":
        os.system("echo '\033[0;35m'" + textOfColor)

    if nameOfColor == "cyan":
        os.system("echo '\033[0;36m'" + textOfColor)

    if nameOfColor == "lightgray":
        os.system("echo '\033[0;37m'" + textOfColor)

    if nameOfColor == "darkgrey":
        os.system("echo '\033[1;30m'" + textOfColor)

    if nameOfColor == "yellow":
        os.system("echo '\033[1;33m'" + textOfColor)

def UConsoleInput(variableOfInput, textOfInput):
    variableOfInput = input(textOfInput)

def USystemShellCommand(CommandShell):
    os.system(CommandShell)

def USystemListDirFile():
    os.system("ls")

def USystemMakeArchiveFile(VarArchiveFile, NameOfArchiveFile, ExtensionOfArchiveFile):
    VarArchiveFile = ZipFile(NameOfArchiveFile + '.' + ExtensionOfArchiveFile, 'w')
    VarArchiveFile.close()

def UConsoleSystemBashCreateFile(nameOfYourCustomFile, extensionOfYourCustomFile):
    os.system("touch " + nameOfYourCustomFile + extensionOfYourCustomFile)

def UConsoleSystemBashWriteFile(nameOfFileAndExtension, textToWriteInFile):
    os.system("echo " + textToWriteInFile + " >> " + nameOfFileAndExtension)

def UConsoleSystemBashCreateDirectory(nameOfDirectoryToCreate):
    os.system("mkdir " + nameOfDirectoryToCreate)

def UConsoleSystemBashDeleteDirectory(nameOfDirectoryToDelete):
    os.system("rm -r " + nameOfDirectoryToDelete)

def UConsoleSystemBashDeleteFile(nameOfFileToDelete):
    os.system("rm " + nameOfFileToDelete)

def USystemKernelHash(textToHash):
    os.system("echo -n " + textToHash + " | md5sum")

def USystemExecuteShellFile(shellFileToExecute):
    os.system("sh " + shellFileToExecute)

def USystemUNIXInfo():
    os.system("uname -a")

def USystemShellCurrentUser():
    os.system("whoami")

def USystemKernelSudo(commandToSudo):
    os.system("sudo " + commandToSudo)

def USystemKernelSudoApt(commandToSudoApt):
    os.system("sudo apt " + commandToSudoApt)

def USystemShellChmod(typeOfChmod, directoryOfChmodOrFile):
    os.system("chmod " + typeOfChmod + directoryOfChmodOrFile)